#  The socialization of meritocracy and market justice preferences at school - MDPI Submit

* Due to submission requirements, only the .tex and .pdf files are included here. The paper-blinded.tex and paper-blinded.pdf files are anonymized copies of the original manuscript located in the root of this repository. For the most recent version of the manuscript, please refer to the main file.

* This article was prepared using the [Andrew Heiss academic template for Quarto](https://github.com/andrewheiss/hikmah-academic-quarto/tree/main) and verified for correct rendering with the online[Overleaf template]((https://www.overleaf.com/latex/templates/mdpi-article-template/fcpwsspfzsph)). 



